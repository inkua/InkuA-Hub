<?php
return array (
  'Already requested' => '',
  'Request sent' => '',
  'You have insufficient permissions to perform that operation!' => 'Bạn không đủ thẩm quyền thực hiện hành động này!',
);
