<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} heeft u verantwoordelijk gemaakt voor taak {task} vanuit de ruimte {spaceName}.',
);
