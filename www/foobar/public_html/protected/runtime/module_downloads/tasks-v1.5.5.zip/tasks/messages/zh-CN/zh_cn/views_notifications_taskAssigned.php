<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} 分配任务给你: {task} .',
);
