<?php
return array (
  '{userName} created task {task}.' => '{userName} đã tạo công việc {task}.',
);
