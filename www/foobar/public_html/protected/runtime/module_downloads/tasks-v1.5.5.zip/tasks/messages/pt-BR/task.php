<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Permite ao usuário criar, excluir e editar tarefas e listas e também classificar tarefas e listas',
  'Allows the user to process unassigned tasks' => 'Permite que o usuário processe tarefas não atribuídas',
  'Manage tasks' => 'Gerenciar tarefas',
  'Process unassigned tasks' => 'Processar tarefas não atribuídas',
);
