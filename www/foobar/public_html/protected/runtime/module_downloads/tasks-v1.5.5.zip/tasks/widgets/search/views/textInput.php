<?php
/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2018 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 *
 */

use yii\bootstrap\Html;

/* @var $this \humhub\modules\ui\view\components\View */
?>
<div class="form-group">
    <?= Html::textInput(null,null, $options) ?>
</div>
