<?php
return array (
  'Drag list' => 'Sleep lijst',
);
