<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Xác nhận</strong> xóa',
  'Add Task' => 'Thêm công việc',
  'Cancel' => 'Hủy',
  'Delete' => 'Xóa',
  'Do you really want to delete this task?' => 'Bạn thực sự muốn xóa công việc này?',
  'No open tasks...' => 'Không có công việc nào được mở...',
  'completed tasks' => 'Các công việc đã hoàn thành',
);
