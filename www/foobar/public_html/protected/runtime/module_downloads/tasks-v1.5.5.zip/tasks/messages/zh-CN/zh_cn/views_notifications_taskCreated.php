<?php
return array (
  '{userName} created a new task {task}.' => '{userName} 创建了一个新任务 {task}.',
);
