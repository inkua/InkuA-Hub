<?php
return array (
  'End Date' => 'Einddatum',
  'End Time' => 'Eindtijd',
  'End time must be after start time!' => 'Eindtijd moet na de starttijd liggen!',
  'Public' => 'Openbaar',
  'Start Date' => 'Startdatum',
  'Start Time' => 'Starttijd',
  'Time Zone' => 'Tijdzone',
);
