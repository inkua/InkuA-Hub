<?php
return array (
  'Created by me' => 'Tạo bởi tôi',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Các phòng làm việc',
  'Start date' => '',
  'Status' => 'Trạng thái',
  'Title' => 'Tiêu đề',
);
