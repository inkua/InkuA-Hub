<?php
return array (
  'Created by me' => 'Von mir erstellt',
  'End date' => 'Enddatum',
  'Filter status' => 'Statusfilter',
  'Filter tasks' => 'Aufgaben filtern',
  'I\'m assigned' => 'Mir zugewiesen',
  'I\'m responsible' => 'Ich bin verantwortlich',
  'Overdue' => 'Überfällig',
  'Spaces' => 'Spaces',
  'Start date' => 'Startdatum',
  'Status' => 'Status',
  'Title' => 'Titel',
);
