<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} đã được giao công việc {task}.',
);
