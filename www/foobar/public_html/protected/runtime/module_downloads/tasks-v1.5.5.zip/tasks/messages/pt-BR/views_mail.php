<?php
return array (
  'Your Reminder for task {task}' => 'Seu lembrete para a tarefa {task}',
);
