<?php
return array (
  '{userName} finished task {task}.' => '{userName} 完成任务 {task}.',
);
