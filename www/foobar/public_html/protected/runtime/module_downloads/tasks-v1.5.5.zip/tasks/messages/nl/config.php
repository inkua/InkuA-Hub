<?php
return array (
  '<strong>Task</strong> module configuration' => '<strong>Taak strong&gt;-module configureren</strong>',
  'Displays a global task menu item on the main menu.' => 'Toont een globaal taakmenu-item in het hoofdmenu.',
  'Global task menu item' => 'Algemeen taakmenu-item',
  'Max tasks items' => 'Maximaal aantal taken',
  'Menu Item sort order' => 'Sorteervolgorde menu-items',
  'Show global task menu item' => 'Toon globaal taakmenu-item',
  'Show snippet' => 'Fragment weergeven',
  'Show snippet in Space' => 'Fragment in ruimte weergeven',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Toont een widget met aan uw toegewezen of verantwoordelijke taken op het dashboard.',
  'Shows the widget also on the dashboard of spaces.' => 'Toont de widget ook op het dashboard van ruimtes',
  'Sort order' => 'Sorteervolgorde',
  'Your tasks snippet' => 'Uw taakfragment',
);
