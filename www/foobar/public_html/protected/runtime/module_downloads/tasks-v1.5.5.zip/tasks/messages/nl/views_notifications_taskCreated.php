<?php
return array (
  '{userName} created a new task {task}.' => '{userName} heeft een nieuwe taak gemaakt: {task}.',
);
