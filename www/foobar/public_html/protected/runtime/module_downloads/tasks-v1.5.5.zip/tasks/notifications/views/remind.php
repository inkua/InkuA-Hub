<?php $this->beginContent('@tasks/notifications/views/layouts/remind.php', $_params_); ?>
    <?= $html; ?>
<?php $this->endContent(); ?>