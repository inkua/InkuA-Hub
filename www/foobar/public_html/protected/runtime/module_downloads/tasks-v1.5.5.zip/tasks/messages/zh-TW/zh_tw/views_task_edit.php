<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => '',
  'Deadline' => '',
  'Save' => '儲存',
  'What is to do?' => '',
);
