<?php
return array (
  'Completed' => 'Fertiggestellt',
  'Title' => 'Titel',
);
