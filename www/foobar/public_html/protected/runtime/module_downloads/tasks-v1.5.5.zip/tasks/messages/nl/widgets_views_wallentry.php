<?php
return array (
  'Anyone can work on this task!' => 'Iedereen kan aan deze taak werken!',
  'Open Task' => 'Open taak',
  'This task can only be processed by assigned and responsible users.' => 'Alleen toegewezen of verantwoordelijke gebruikers kunnen werken aan deze taak.',
);
