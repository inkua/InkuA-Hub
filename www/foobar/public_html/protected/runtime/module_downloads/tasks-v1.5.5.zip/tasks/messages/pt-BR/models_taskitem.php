<?php
return array (
  'Completed' => 'Concluída',
  'Title' => 'Título',
);
