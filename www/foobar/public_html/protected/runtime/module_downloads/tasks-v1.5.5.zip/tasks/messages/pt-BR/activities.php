<?php
return array (
  '{userName} completed task {task}.' => '{userName} completou a tarefa {task}.',
  '{userName} reset task {task}.' => '{userName} redefiniu a tarefa {task}.',
  '{userName} reviewed task {task}.' => '{userName} revisou a tarefa {task}.',
  '{userName} works on task {task}.' => '{userName} trabalhou na tarefa {task}.',
);
