<?php
return array (
  'Completed' => '',
  'Title' => '제목',
);
