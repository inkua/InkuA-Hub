<?php

return [
    '<strong>Create</strong> new task' => '<strong>Tạo</strong> công việc mới',
    '<strong>Edit</strong> task' => '<strong>Chỉnh sửa</strong> công việc',
    'Assign users' => 'Giao việc',
    'Basic' => 'Cơ bản',
    'Do you really want to delete this task?' => 'Bạn thực sự muốn xóa công việc này?',
    'Files' => 'Files',
    '<strong>Confirm</strong> task deletion' => '',
    'Add checkpoint...' => '',
    'Add reminder' => '',
    'Add responsible users' => '',
    'Assignment' => '',
    'Checklist' => '',
    'Edit item (empty field will be removed)...' => '',
    'Leave empty to let anyone work on this task.' => '',
    'Scheduling' => '',
    'Title and Color' => '',
    'Title of your task list' => '',
];
