<?php
return array (
  'Could not access task!' => 'Geen toegang tot de taak!',
);
