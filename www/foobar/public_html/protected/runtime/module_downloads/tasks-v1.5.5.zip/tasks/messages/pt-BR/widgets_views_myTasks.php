<?php
return array (
  '<strong>Your</strong> tasks' => '<strong> Suas </strong> tarefas',
);
