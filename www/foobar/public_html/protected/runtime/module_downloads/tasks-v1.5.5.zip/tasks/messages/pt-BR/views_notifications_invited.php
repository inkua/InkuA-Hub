<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} designou você como pessoa responsável na tarefa {task} do espaço {spaceName}.',
);
