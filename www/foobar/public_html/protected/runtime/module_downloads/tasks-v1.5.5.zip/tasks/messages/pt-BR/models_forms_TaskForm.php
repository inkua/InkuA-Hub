<?php
return array (
  'End Date' => 'Data final',
  'End Time' => 'Fim do tempo',
  'End time must be after start time!' => 'A hora de término deve ser posterior à hora de início!',
  'Public' => 'Público',
  'Start Date' => 'Data de início',
  'Start Time' => 'Hora de início',
  'Time Zone' => 'Fuso horário',
);
