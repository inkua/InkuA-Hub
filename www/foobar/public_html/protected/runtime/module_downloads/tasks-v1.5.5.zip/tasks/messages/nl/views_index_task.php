<?php
return array (
  'Task Users have been notified' => 'De betrokken gebruikers zijn op de hoogte gebracht.',
);
