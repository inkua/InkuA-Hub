<?php
return array (
  'Click, to finish this task' => 'Click, để đánh dấu hoàn thành công việc',
  'This task is already done. Click to reopen.' => 'Công việc này đã được hoàn thành. Click để mở lại.',
);
