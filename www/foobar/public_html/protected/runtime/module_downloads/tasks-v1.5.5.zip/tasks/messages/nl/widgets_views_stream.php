<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Er zijn nog geen taken!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Er zijn nog geen taken!</b><br>Wees de eerste en maak er een...',
  'Assigned to me' => 'Toegewezen aan mij',
  'Back to stream' => 'Terug naar stream',
  'Created by me' => 'Gemaakt door mij',
  'Creation time' => 'Aanmaak datum',
  'Filter' => 'Filter',
  'Last update' => 'Laatste bijwerk datum',
  'No tasks found which matches your current filter(s)!' => 'Geen taken gevonden die voldoen aan uw filter(s)!',
  'Nobody assigned' => 'Niemand gekoppeld',
  'Sorting' => 'Sortering',
  'State is finished' => 'Taak is voltooid',
  'State is open' => 'Taak is open',
);
