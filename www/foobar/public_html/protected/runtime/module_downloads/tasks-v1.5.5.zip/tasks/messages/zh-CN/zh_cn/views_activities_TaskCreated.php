<?php
return array (
  '{userName} created task {task}.' => '{userName} 创建任务 {task}.',
);
