<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Chưa có công việc nào!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Chưa có công việc nào!</b><br>Hãy là người đầu tiên tạo công việc...',
  'Assigned to me' => 'Được giao cho tôi',
  'Back to stream' => '@@Quay lại nhóm @@',
  'Created by me' => 'Tạo bởi tôi',
  'Creation time' => 'Thời gian tạo',
  'Filter' => 'Lọc',
  'Last update' => 'Cập nhật cuối cùng',
  'No tasks found which matches your current filter(s)!' => '@@@@',
  'Nobody assigned' => 'Chưa giao cho ai',
  'Sorting' => 'Sắp xếp',
  'State is finished' => 'Trạng thái đã hoàn thành',
  'State is open' => 'Trạng thái đang mở',
);
