<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => '取消',
  'Deadline' => '',
  'Save' => '保存',
  'What is to do?' => '',
);
