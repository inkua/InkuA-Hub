<?php

return [
    '<strong>Confirm</strong> task deletion' => '<strong> Confirmar </strong> exclusão da tarefa',
    '<strong>Create</strong> new task' => '<strong> Criar </strong> nova tarefa',
    '<strong>Edit</strong> task' => 'Tarefa <strong> Editar </strong>',
    'Add checkpoint...' => 'Adicionar ponto de verificação ...',
    'Add reminder' => 'Adicionar lembrete',
    'Add responsible users' => 'Adicione usuários responsáveis',
    'Assign users' => 'Atribuir usuários',
    'Assignment' => 'Tarefa',
    'Basic' => 'Básico',
    'Checklist' => 'Lista de controle',
    'Do you really want to delete this task?' => 'Deseja realmente excluir esta tarefa?',
    'Edit item (empty field will be removed)...' => 'Editar item (o campo vazio será removido) ...',
    'Files' => 'Arquivos',
    'Leave empty to let anyone work on this task.' => 'Deixe em branco para permitir que alguém trabalhe nessa tarefa.',
    'Scheduling' => 'Agendamento',
    'Title and Color' => 'Título e Cor',
    'Title of your task list' => '',
];
