<?php
return array (
  '1 Day before' => '1 dia antes',
  '1 Month before' => '1 mês antes',
  '1 Week before' => '1 semana antes',
  '2 Days before' => '2 dias antes',
  '2 Weeks before' => '2 Semanas antes',
  '3 Weeks before' => '3 semanas antes',
  'At least 1 Hour before' => 'Pelo menos 1 hora antes',
  'At least 2 Hours before' => 'Pelo menos 2 horas antes',
  'Do not remind' => 'Não lembre',
  'Remind Mode' => 'Modo Lembrar',
  'Task' => 'Tarefa',
);
