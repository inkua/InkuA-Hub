<?php
return array (
  'End Date' => 'Ngày kết thúc',
  'End Time' => 'Giờ kết thúc',
  'End time must be after start time!' => 'Ngày kết thúc phải sau ngày bắt đầu!',
  'Public' => 'Công cộng',
  'Start Date' => 'Ngày bắt đầu',
  'Start Time' => 'Thời gian bắt đầu',
  'Time Zone' => 'Múi giờ',
);
