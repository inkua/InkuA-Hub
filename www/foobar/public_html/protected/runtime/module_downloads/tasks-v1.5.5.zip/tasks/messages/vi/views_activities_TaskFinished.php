<?php
return array (
  '{userName} finished task {task}.' => '{userName} đã hoàn thành công việc {task}.',
);
