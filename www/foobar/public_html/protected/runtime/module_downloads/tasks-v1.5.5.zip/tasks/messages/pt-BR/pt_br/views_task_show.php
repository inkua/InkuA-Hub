<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Confirmar</strong> exclusão',
  'Add Task' => 'Adicionar tarefa',
  'Cancel' => 'Cancelar',
  'Delete' => 'Excluir',
  'Do you really want to delete this task?' => 'Você realmente quer excluir esta tarefa?',
  'No open tasks...' => 'Não há tarefas abertas...',
  'completed tasks' => 'Tarefas finalizadas',
);
