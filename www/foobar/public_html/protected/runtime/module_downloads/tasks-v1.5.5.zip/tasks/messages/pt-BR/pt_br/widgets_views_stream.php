<?php
return array (
  'Back to stream' => '@@Voltar para o stream@@',
  'No tasks found which matches your current filter(s)!' => '@@Nenhuma tarefa encontrada que corresponda ao seu(s) filtro(s) atual(ais)!@@',
  '<b>There are no tasks yet!</b>' => '<b>Não há tarefas ainda!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Não há tarefas ainda!</b><br>Seja o primeiro e criar uma...',
  'Assigned to me' => 'Designado para mim',
  'Created by me' => 'Criado por mim',
  'Creation time' => 'Hora de criação',
  'Filter' => 'Filtro',
  'Last update' => 'Última atualização',
  'Nobody assigned' => 'Ninguém atribuído',
  'Sorting' => 'Ordenando',
  'State is finished' => 'Estado está finalizado',
  'State is open' => 'Estado está aberto',
);
