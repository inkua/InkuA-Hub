<?php
return array (
  'Already requested' => 'Já solicitado',
  'Request sent' => 'Pedido enviado',
  'You have insufficient permissions to perform that operation!' => 'Você tem permissões insuficientes para executar essa operação!',
);
