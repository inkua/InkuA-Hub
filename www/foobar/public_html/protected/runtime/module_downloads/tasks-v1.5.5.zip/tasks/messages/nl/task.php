<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Hiermee kan de gebruiker taken en lijsten maken, verwijderen, bewerken en sorteren.',
  'Allows the user to process unassigned tasks' => 'Hiermee kan de gebruiker niet-toegewezen taken verwerken.',
  'Manage tasks' => 'Beheer taken',
  'Process unassigned tasks' => 'Verwerk niet-toegewezen taken',
);
