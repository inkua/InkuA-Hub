<?php

return [
    'Basic' => '基础',
    'Files' => '附件设置',
    '<strong>Confirm</strong> task deletion' => '',
    '<strong>Create</strong> new task' => '',
    '<strong>Edit</strong> task' => '',
    'Add checkpoint...' => '',
    'Add reminder' => '',
    'Add responsible users' => '',
    'Assign users' => '',
    'Assignment' => '',
    'Checklist' => '',
    'Do you really want to delete this task?' => '',
    'Edit item (empty field will be removed)...' => '',
    'Leave empty to let anyone work on this task.' => '',
    'Scheduling' => '',
    'Title and Color' => '',
    'Title of your task list' => '',
];
