<?php
return array (
  'End Date' => 'Data Final',
  'End Time' => 'Hora de término',
  'End time must be after start time!' => 'A hora de término precisa ser depois da hora de início!',
  'Public' => 'Público',
  'Start Date' => 'Data de Inicio',
  'Start Time' => 'Hora de início',
  'Time Zone' => 'Fuso horário',
);
