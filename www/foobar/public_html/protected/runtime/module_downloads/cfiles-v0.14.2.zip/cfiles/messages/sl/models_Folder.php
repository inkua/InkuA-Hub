<?php
return array (
  'Description' => '',
  'Parent Folder ID' => '',
  'Title' => 'Naslov',
);
