<?php
return array (
  'Description' => 'Opis',
  'Parent Folder ID' => 'ID Foldera Nadrzeędnego',
  'Title' => 'Tytuł',
);
