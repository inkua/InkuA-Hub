<?php
return array (
  'Description' => 'Descripción',
  'Parent Folder ID' => '',
  'Title' => 'Titulek',
);
