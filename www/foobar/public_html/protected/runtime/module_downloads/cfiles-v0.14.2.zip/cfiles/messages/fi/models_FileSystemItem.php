<?php

return [
    'Is Public' => 'Julkinen',
    'Note: Changes of the folders visibility, will be inherited by all contained files and folders.' => '<strong>Huomaa:</strong> Muutokset kansioiden näkyvyydestä muokkaavat myös kaikkia suljettuja tiedostoja ja kansioita.',
    'Downloads' => '',
];
