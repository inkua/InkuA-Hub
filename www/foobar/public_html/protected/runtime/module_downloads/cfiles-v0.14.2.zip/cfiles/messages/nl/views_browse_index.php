<?php
return array (
  'Could not save file %title%. ' => 'Kon bestand %title% niet opslaan.',
);
