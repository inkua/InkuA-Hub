<?php
return array (
  'Could not save file %title%. ' => 'Не удалось сохранить файл %title%. ',
);
