<?php
return array (
  'Are you really sure to delete this version?' => 'Weet u zeker dat u deze versie wilt verwijderen?',
  'The version "{versionDate}" could not be deleted!' => 'De versie "{versionDate}" kan niet worden verwijderd!',
  'The version "{versionDate}" has been deleted.' => 'De versie "{versionDate}" is verwijderd.',
);
