<?php
return array (
  'Folder ID' => 'Αναγνωριστικό φακέλου (ID)',
);
