<?php
return array (
  'Description' => 'Descriere',
  'Parent Folder ID' => '',
  'Title' => 'Titlul',
);
