<?php
return array (
  'Folder ID' => 'Map ID',
);
