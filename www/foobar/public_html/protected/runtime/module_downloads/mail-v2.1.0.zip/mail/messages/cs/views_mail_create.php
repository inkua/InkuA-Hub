<?php
return array (
  '<strong>New</strong> message' => '<strong>Nová</strong> zpráva',
  'Add recipients' => 'Přidat příjemce',
  'Send' => 'Poslat',
);
