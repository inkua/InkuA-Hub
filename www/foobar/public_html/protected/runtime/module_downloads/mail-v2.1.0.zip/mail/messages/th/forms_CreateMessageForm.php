<?php
return array (
  'Message' => 'ข้อความ',
  'Recipient' => 'ผู้รับ',
  'Subject' => 'เรื่อง',
  'Tags' => 'แท็ก',
);
