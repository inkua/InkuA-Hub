<?php
return array (
  'Recipient' => 'Primatelj',
  'User {name} is already participating!' => 'Korisnik {name} već sudjeluje!',
  'You are not allowed to send user {name} is already!' => 'Ne smijete slati korisnika {name} je već!',
  'You cannot send a email to yourself!' => 'Ne možete poslati email sami sebi!',
);
