<?php
return array (
  '<strong>New</strong> message' => '<strong>Nuevo</strong> mensaje',
  'Add recipients' => 'Agregar destinatarios',
  'Send' => 'Enviar',
);
