<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'Příjemce',
    'You cannot send a email to yourself!' => 'Nemůžete poslat zprávu sami sobě.',
];
