<?php

return [
    'Cancel' => 'Anulează',
    'Delete' => 'Șterge',
    '<strong>Confirm</strong> deleting conversation' => '',
    '<strong>Confirm</strong> leaving conversation' => '',
    '<strong>Confirm</strong> message deletion' => '',
    'Add user' => '',
    'Delete conversation' => '',
    'Do you really want to delete this conversation?' => '',
    'Do you really want to delete this message?' => '',
    'Do you really want to leave this conversation?' => '',
    'Leave' => '',
    'Leave conversation' => '',
    'There are no messages yet.' => '',
];
