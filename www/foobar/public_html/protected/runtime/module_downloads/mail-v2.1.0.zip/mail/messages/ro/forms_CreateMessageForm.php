<?php

return [
    'Message' => 'Mesaj',
    'Subject' => '제목',
    'Recipient' => '',
    'Tags' => '',
];
