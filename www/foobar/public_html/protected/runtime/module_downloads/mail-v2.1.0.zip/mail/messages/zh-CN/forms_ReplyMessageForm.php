<?php
return array (
  'Message' => '消息',
);
