<?php

return [
    'Send message' => '',
];
