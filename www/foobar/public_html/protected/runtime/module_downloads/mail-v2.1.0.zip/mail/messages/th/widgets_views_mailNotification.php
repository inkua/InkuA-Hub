<?php
return array (
  'Show all messages' => 'แสดงข้อความทั้งหมด',
);
