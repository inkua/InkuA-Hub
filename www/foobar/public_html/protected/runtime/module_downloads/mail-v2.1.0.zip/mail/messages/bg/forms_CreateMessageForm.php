<?php
return array (
  'Message' => 'Съобщение',
  'Recipient' => 'Получател',
  'Subject' => 'Тема',
  'Tags' => 'Етикети',
);
