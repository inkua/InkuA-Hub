<?php

return [
    'New message from {senderName}' => 'Uusi viesti lähetäjältä {senderName}',
    'New conversation from {senderName}' => '',
];
