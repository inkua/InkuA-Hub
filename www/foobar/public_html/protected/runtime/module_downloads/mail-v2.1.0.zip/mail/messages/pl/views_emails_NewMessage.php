<?php

return [
    '<strong>New</strong> message' => '<strong>Nowa</strong> wiadomość ',
    'Reply now' => 'Odpowiedz teraz ',
    '<strong>New</strong> conversation' => '',
];
