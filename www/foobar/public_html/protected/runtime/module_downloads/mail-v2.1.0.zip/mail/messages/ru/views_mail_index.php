<?php
return array (
  'Conversations' => 'Чаты',
  'New' => 'Новое',
  'There are no messages yet.' => 'Здесь пока нет сообщений.',
);
