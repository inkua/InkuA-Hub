<?php
return array (
  '<strong>New</strong> message' => '<strong>ใหม่</strong> ข้อความ',
  'Add recipients' => 'เพิ่มผู้รับ',
  'Send' => 'ส่ง',
);
