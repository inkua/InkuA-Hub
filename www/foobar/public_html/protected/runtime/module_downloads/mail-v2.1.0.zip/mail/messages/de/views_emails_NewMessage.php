<?php

return [
    '<strong>New</strong> message' => '<strong>Neue</strong> Nachricht',
    'Reply now' => 'Antworte jetzt',
    '<strong>New</strong> conversation' => '',
];
