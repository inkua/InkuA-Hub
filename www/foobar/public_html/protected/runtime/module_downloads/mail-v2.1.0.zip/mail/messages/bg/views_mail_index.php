<?php
return array (
  'Conversations' => 'Обсъждания',
  'New' => 'Нов',
  'There are no messages yet.' => 'Все още нямате съобщения.',
);
