<?php
return array (
  'Show all messages' => 'Покажи всички съобщения',
);
