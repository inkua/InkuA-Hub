<?php
return array (
  '<strong>New</strong> message' => '<strong>Ново</strong> съобщение',
  'Add recipients' => 'Добави получатели',
  'Send' => 'Изпрати',
);
