<?php

return [
    'Edit message entry' => 'Uredi unos poruka',
];
