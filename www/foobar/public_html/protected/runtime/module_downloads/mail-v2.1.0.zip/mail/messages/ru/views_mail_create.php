<?php
return array (
  '<strong>New</strong> message' => '<strong>Новое</strong> сообщение',
  'Add recipients' => 'Добавить получателей',
  'Send' => 'Отправить',
);
