<?php
return array (
  '<strong>New</strong> message' => '<strong>Jauna</strong> ziņa',
  'Add recipients' => 'Pievieno saņēmējus',
  'Send' => 'Sūtīt',
);
