<?php

return [
    'Conversations' => '',
    'New' => '',
    'There are no messages yet.' => '',
];
