<?php
return array (
  'New conversation from {senderName}' => 'Nueva conversación de {senderName}',
  'New message from {senderName}' => 'Nuevo mensaje de {senderName}',
);
