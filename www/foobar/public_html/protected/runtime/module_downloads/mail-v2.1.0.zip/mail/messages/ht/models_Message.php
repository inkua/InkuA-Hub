<?php

return [
    'New conversation from {senderName}' => '',
    'New message from {senderName}' => '',
];
