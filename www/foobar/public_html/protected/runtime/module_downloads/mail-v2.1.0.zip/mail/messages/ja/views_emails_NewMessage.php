<?php

return [
    '<strong>New</strong> message' => '<strong>New</strong> メッセージ',
    'Reply now' => '返信',
    '<strong>New</strong> conversation' => '',
];
