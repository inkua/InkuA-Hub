<?php
return array (
  'Message' => 'Zpráva',
  'Recipient' => 'Příjemce',
  'Subject' => 'Předmět',
  'Tags' => 'Štítky',
);
