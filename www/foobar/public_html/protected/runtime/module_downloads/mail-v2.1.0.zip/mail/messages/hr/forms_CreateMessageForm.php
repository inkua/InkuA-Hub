<?php
return array (
  'Message' => 'Poruka',
  'Recipient' => 'Primatelj',
  'Subject' => 'Predmet',
  'Tags' => 'Tagovi',
);
