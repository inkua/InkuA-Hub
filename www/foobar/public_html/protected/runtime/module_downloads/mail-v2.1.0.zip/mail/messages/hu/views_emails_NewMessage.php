<?php

return [
    '<strong>New</strong> message' => '<strong>Új</strong> üzenet',
    'Reply now' => 'Válasz most',
    '<strong>New</strong> conversation' => '',
];
