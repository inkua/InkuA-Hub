<?php
return array (
  'Sign up now' => 'สมัครตอนนี้เลย',
);
