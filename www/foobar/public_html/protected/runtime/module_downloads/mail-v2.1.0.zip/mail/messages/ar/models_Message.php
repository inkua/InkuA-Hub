<?php

return [
    'New message from {senderName}' => 'رسالة جديدة من {senderName}',
    'New conversation from {senderName}' => '',
];
