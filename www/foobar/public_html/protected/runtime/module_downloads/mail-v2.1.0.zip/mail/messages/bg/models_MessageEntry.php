<?php
return array (
  'New message in discussion from %displayName%' => 'Ново съобщение в дискусия от %displayName%',
);
