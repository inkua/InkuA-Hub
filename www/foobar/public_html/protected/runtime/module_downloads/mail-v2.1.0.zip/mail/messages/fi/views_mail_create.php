<?php
return array (
  '<strong>New</strong> message' => '<strong>Uusi</strong> viesti',
  'Add recipients' => 'Lisää vastaanottajia',
  'Send' => 'Lähetä',
);
