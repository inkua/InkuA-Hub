<?php

return [
    'Show all messages' => 'Näytä kaikki viestit',
];
