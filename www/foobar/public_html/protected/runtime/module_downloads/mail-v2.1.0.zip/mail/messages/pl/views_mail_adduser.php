<?php

return [
    'Add more participants to your conversation...' => 'Dodaj więcej odbiorców do twojej konwersacji ',
];
