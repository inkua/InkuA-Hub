<?php
return array (
  'Message' => 'Съобщение',
);
