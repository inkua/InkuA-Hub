<?php

return [
    'Show all messages' => 'Vis alle meldinger',
];
