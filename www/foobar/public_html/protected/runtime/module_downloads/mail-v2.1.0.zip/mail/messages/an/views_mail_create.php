<?php
return array (
  '<strong>New</strong> message' => '<strong>Nuevo</strong> mensache',
  'Add recipients' => '',
  'Send' => 'Ninviar',
);
