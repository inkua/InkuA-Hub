<?php

return [
    'Send message' => 'Viesti',
];
