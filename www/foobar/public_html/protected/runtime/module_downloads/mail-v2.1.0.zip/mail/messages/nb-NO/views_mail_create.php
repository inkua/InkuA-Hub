<?php
return array (
  '<strong>New</strong> message' => '<strong>Ny</strong> melding',
  'Add recipients' => 'Legg til mottakere',
  'Send' => 'Send',
);
