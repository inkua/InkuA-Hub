<?php

return [
    'Add more participants to your conversation...' => 'Legg til flere deltagere i denne samtalen...',
];
