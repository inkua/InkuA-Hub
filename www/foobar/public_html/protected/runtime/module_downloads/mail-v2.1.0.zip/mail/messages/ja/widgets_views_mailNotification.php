<?php

return [
    'Show all messages' => '全てのメッセージを表示',
];
