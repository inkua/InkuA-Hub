<?php
return array (
  'Edit message entry' => 'แก้ไขรายการข้อความ',
);
