<?php

return [
    '{senderName} created a new conversation {conversationTitle}' => '',
    '{senderName} sent you a new message in {conversationTitle}' => '',
];
