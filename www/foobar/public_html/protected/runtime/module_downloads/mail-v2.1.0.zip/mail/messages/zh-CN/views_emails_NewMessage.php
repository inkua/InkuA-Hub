<?php

return [
    '<strong>New</strong> message' => '新<strong>消息</strong>',
    'Reply now' => '现在回复',
    '<strong>New</strong> conversation' => '',
];
