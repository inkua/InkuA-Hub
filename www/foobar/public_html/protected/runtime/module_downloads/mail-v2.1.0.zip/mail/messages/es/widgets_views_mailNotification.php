<?php

return [
    'Show all messages' => 'Mostrar todos los mensajes',
];
