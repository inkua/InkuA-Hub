<?php
return array (
  '<strong>New</strong> message' => '<strong>Neue</strong> Nachricht',
  'Add recipients' => 'Empfänger hinzufügen',
  'Send' => 'Senden',
);
