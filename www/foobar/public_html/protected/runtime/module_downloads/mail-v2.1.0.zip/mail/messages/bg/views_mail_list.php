<?php
return array (
  'There are no messages yet.' => 'Все още нямате съобщения.',
);
