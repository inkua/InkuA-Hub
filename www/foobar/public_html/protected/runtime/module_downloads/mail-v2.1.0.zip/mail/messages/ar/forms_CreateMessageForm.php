<?php
return array (
  'Message' => 'الرسالة',
  'Recipient' => 'المستلم',
  'Subject' => 'عنوان الرسالة',
  'Tags' => 'الأوسمة',
);
