<?php
return array (
  '<strong>New</strong> message' => 'رسالة <strong>جديدة</strong>',
  'Add recipients' => '',
  'Send' => 'ارسال',
);
