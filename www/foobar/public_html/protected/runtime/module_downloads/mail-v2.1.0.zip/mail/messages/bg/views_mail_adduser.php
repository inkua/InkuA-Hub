<?php
return array (
  'Add more participants to your conversation...' => 'Добави още участници към твоето обсъждане...',
);
