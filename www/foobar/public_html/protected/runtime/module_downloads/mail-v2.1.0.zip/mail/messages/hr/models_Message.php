<?php

return [
    'New message from {senderName}' => 'Nova poruka od {senderName}',
    'New conversation from {senderName}' => '',
];
