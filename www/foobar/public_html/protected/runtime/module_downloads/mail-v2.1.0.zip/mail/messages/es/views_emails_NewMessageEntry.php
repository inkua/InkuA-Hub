<?php
return array (
  '{senderName} created a new conversation {conversationTitle}' => '{senderName} ha creado una nueva conversación {conversationTitle}',
  '{senderName} sent you a new message in {conversationTitle}' => '{senderName} te ha enviado un nuevo mensaje en {conversationTitle}',
);
