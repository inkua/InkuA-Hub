<?php

return [
    '<strong>New</strong> message' => '<strong>Nová</strong> zpráva',
    'Reply now' => 'Odpovědět',
    '<strong>New</strong> conversation' => '',
];
