<?php
return array (
  'Message' => 'Nachricht',
  'Recipient' => 'Empfänger',
  'Subject' => 'Betreff',
  'Tags' => 'Tags',
);
