<?php

return [
    'New message from {senderName}' => 'Jauna ziņa no {senderName}',
    'New conversation from {senderName}' => '',
];
