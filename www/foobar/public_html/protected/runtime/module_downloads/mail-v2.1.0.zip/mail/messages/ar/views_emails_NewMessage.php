<?php

return [
    '<strong>New</strong> message' => 'رسالة <strong>جديدة</strong>',
    'Reply now' => 'اضف رد',
    '<strong>New</strong> conversation' => '',
];
