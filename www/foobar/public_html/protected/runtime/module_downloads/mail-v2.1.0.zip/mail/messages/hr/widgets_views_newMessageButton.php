<?php

return [
    'Send message' => 'Pošalji poruku',
];
