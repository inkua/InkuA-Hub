<?php

return [
    'New message from {senderName}' => 'Ново съобщение от {senderName}',
    'New conversation from {senderName}' => '',
];
