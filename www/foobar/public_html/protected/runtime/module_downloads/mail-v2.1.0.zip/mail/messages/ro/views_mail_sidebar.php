<?php
return array (
  'Groups' => 'Grupuri',
  'Members' => 'Membri',
  'Spaces' => 'Spatii',
  'User Posts' => '',
);
