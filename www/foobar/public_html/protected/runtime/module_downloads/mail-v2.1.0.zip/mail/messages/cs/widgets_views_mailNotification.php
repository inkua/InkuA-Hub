<?php

return [
    'Show all messages' => 'Zobrazit všechny zprávy',
];
