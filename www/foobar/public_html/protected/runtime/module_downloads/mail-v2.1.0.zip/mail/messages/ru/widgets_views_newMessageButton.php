<?php

return [
    'Send message' => 'Отправить сообщение',
];
