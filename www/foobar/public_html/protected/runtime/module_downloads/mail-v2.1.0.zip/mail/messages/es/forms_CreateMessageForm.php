<?php
return array (
  'Message' => 'Mensaje',
  'Recipient' => 'Destinatario',
  'Subject' => 'Asunto',
  'Tags' => 'Etiquetas',
);
