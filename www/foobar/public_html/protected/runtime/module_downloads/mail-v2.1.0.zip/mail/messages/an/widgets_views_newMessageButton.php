<?php

return [
    'Send message' => 'Ninviar mensache',
];
