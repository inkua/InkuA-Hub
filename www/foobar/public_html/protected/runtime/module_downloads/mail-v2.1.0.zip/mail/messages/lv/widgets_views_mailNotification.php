<?php

return [
    'Show all messages' => 'Rādīt visas ziņas',
];
