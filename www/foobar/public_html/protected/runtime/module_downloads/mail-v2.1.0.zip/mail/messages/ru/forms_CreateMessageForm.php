<?php
return array (
  'Message' => 'Сообщение',
  'Recipient' => 'Получатель',
  'Subject' => 'Тема',
  'Tags' => 'Теги',
);
