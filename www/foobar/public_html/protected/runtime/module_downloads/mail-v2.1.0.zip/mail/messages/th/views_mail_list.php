<?php
return array (
  'There are no messages yet.' => 'ยังไม่มีข้อความ.',
);
