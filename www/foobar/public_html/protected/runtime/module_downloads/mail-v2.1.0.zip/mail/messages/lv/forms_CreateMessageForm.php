<?php

return [
    'Message' => 'Ziņojums',
    'Recipient' => 'Saņēmējs',
    'Subject' => 'Tēma',
    'Tags' => '',
];
