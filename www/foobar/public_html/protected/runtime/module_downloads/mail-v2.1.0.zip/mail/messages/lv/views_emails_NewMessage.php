<?php

return [
    '<strong>New</strong> message' => '<strong>Jauna</strong> ziņa',
    'Reply now' => 'Atbildēt tagad',
    '<strong>New</strong> conversation' => '',
];
