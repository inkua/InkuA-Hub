<?php

return [
    'Add more participants to your conversation...' => '',
];
