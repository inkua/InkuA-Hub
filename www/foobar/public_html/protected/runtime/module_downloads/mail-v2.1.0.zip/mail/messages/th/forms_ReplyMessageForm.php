<?php
return array (
  'Message' => 'ข้อความ',
);
