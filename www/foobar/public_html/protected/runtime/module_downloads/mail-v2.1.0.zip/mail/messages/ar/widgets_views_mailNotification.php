<?php

return [
    'Show all messages' => 'عرض كل الرسائل',
];
