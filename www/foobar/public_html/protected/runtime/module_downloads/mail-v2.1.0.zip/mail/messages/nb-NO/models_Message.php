<?php

return [
    'New message from {senderName}' => 'Ny melding fra {senderName}',
    'New conversation from {senderName}' => '',
];
