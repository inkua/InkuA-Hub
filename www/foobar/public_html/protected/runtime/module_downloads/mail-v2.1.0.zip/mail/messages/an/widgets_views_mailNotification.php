<?php

return [
    'Show all messages' => 'Veyer totz os mensaches',
];
