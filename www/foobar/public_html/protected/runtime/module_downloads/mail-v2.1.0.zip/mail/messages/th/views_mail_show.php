<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>ยืนยัน</strong> กำลังลบการสนทนา',
  '<strong>Confirm</strong> leaving conversation' => '<strong>ยืนยัน</strong> ออกจากการสนทนา',
  '<strong>Confirm</strong> message deletion' => '<strong>ยืนยัน</strong> การลบข้อความ',
  'Add user' => 'เพิ่มผู้ใช้',
  'Cancel' => 'ยกเลิก',
  'Delete' => 'ลบ',
  'Delete conversation' => 'ลบบทสนทนา',
  'Do you really want to delete this conversation?' => 'คุณต้องการลบการสนทนานี้จริงหรือ',
  'Do you really want to delete this message?' => 'คุณต้องการลบข้อความนี้จริงหรือ',
  'Do you really want to leave this conversation?' => 'คุณต้องการออกจากการสนทนานี้หรือไม่?',
  'Leave' => 'ออกจาก',
  'Leave conversation' => 'ออกจากการสนทนา',
  'There are no messages yet.' => 'ยังไม่มีข้อความ.',
);
