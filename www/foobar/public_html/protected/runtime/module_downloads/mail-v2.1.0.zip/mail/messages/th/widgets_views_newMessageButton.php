<?php
return array (
  'Send message' => 'ส่งข้อความ',
);
