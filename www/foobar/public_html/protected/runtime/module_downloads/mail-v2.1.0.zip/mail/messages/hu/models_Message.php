<?php

return [
    'New message from {senderName}' => '{senderName} új üzenetet küldött',
    'New conversation from {senderName}' => '',
];
