<?php
return array (
  'Conversations' => 'บทสนทนา',
  'New' => 'ใหม่',
  'There are no messages yet.' => 'ยังไม่มีข้อความ.',
);
