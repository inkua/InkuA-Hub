<?php

return [
    '<strong>New</strong> conversation' => '',
    '<strong>New</strong> message' => '',
    'Reply now' => '',
];
