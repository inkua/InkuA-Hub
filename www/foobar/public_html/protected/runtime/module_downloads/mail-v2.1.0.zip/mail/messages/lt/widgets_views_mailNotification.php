<?php

return [
    'Show all messages' => 'Rodyti visas žinutes',
];
