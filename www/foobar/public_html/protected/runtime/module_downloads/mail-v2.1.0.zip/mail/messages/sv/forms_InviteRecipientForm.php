<?php
return array (
  'Recipient' => 'Mottagare',
  'User {name} is already participating!' => 'Användare {name} deltar redan!',
  'You are not allowed to send user {name} is already!' => 'Du har inte tillåtelse att skicka användaren {name} is already!',
  'You cannot send a email to yourself!' => 'Du kan inte skicka e-post till dig själv!',
);
