<?php
return array (
  'Message' => 'መልዕክት',
);
