<?php
return array (
  'Message' => 'メッセージ',
  'Recipient' => '受信者',
  'Subject' => '件名',
  'Tags' => 'タグ',
);
