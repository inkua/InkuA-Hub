<?php
return array (
  'New message in discussion from %displayName%' => 'ข้อความใหม่ในการสนทนาจาก %displayName%',
);
