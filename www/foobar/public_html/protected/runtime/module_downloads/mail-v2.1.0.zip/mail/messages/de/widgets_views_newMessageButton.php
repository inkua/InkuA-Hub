<?php

return [
    'Send message' => 'Nachricht senden',
];
