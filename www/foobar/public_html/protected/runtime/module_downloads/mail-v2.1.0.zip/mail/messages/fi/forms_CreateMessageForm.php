<?php
return array (
  'Message' => 'Viesti',
  'Recipient' => 'Vastaanottaja',
  'Subject' => 'Aihe',
  'Tags' => 'Tägit',
);
