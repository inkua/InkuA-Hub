<?php
return array (
  'Recipient' => 'Mottaker',
  'User {name} is already participating!' => 'Brukeren {name} deltar allerede!',
  'You are not allowed to send user {name} is already!' => 'Du har ikke lov til å sende bruker {name} er allerede!',
  'You cannot send a email to yourself!' => 'Du kan ikke sende en e-post til deg selv!',
);
