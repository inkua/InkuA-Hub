<?php

return [
    'Show all messages' => 'Zeige alle Nachrichten',
];
