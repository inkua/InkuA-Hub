<?php

return [
    'Add more participants to your conversation...' => 'Adicionar mais participantes na sua conversa ...',
];
