<?php
return array (
  'Add more participants to your conversation...' => 'เพิ่มผู้เข้าร่วมในการสนทนาของคุณ...',
);
