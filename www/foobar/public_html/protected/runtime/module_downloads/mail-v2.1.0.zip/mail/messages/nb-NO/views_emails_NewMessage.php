<?php

return [
    '<strong>New</strong> message' => '<strong>Ny</strong> melding',
    'Reply now' => 'Svar nå',
    '<strong>New</strong> conversation' => '',
];
