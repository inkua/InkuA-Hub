<?php
return array (
  'Edit message entry' => 'Редактирай съобщението',
);
