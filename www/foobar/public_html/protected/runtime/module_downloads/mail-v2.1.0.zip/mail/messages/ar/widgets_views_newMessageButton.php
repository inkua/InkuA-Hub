<?php

return [
    'Send message' => 'ارسال رسالة',
];
