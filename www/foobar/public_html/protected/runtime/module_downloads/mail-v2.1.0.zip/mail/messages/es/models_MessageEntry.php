<?php
return array (
  'New message in discussion from %displayName%' => 'Nueva respuesta en la conversación de %displayName%',
);
