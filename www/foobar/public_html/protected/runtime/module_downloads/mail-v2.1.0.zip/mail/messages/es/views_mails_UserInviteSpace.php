<?php
return array (
  'Sign up now' => 'Registrarse ahora',
);
