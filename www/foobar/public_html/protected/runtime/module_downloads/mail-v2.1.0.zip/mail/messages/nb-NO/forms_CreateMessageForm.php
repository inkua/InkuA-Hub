<?php
return array (
  'Message' => 'Melding',
  'Recipient' => 'Mottaker',
  'Subject' => 'Tittel',
  'Tags' => 'Tags',
);
