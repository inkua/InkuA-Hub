<?php
return array (
  'Groups' => 'กลุ่ม',
  'Members' => 'สมาชิก',
  'Spaces' => 'ช่องว่าง',
  'User Posts' => 'โพสต์ของผู้ใช้',
);
