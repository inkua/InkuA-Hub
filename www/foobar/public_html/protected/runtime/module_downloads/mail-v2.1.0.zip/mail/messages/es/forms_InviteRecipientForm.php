<?php
return array (
  'Recipient' => 'Destinatario',
  'User {name} is already participating!' => '¡El usuario {name} está participando ya!',
  'You are not allowed to send user {name} is already!' => '¡No está permitido que le envíes una invitación a {name}!',
  'You cannot send a email to yourself!' => 'No te puedes enviar mensajes tu mismo!',
);
