<?php
return array (
  'New conversation from {senderName}' => 'Neue Unterhaltung gestartet von {senderName}',
  'New message from {senderName}' => 'Neue Nachricht von {senderName}',
);
