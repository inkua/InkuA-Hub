<?php

return [
    'Send message' => 'Poslat zprávu',
];
