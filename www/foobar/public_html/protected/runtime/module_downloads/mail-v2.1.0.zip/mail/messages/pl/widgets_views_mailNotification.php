<?php

return [
    'Show all messages' => 'Pokaż wszystkie wiadomości ',
];
