<?php

return [
    '<strong>New</strong> message' => '<strong>ใหม่</strong> ข้อความ',
    'Reply now' => 'ตอบกลับตอนนี้',
    '<strong>New</strong> conversation' => '',
];
