<?php

return [
    'Add user' => 'ユーザーを追加',
    'Cancel' => 'キャンセル',
    'Delete' => '削除',
    'There are no messages yet.' => 'まだ何もメッセージはありません。',
    '<strong>Confirm</strong> deleting conversation' => '',
    '<strong>Confirm</strong> leaving conversation' => '',
    '<strong>Confirm</strong> message deletion' => '',
    'Delete conversation' => '',
    'Do you really want to delete this conversation?' => '',
    'Do you really want to delete this message?' => '',
    'Do you really want to leave this conversation?' => '',
    'Leave' => '',
    'Leave conversation' => '',
];
