<?php

return [
    'Edit message entry' => '',
];
