<?php
return array (
  'Send message' => 'Изпрати съобщение',
);
