<?php
return array (
  'Groups' => 'Grupos',
  'Members' => 'Miembros',
  'Spaces' => 'Espacios',
  'User Posts' => 'Publicacions d\'usuario',
);
