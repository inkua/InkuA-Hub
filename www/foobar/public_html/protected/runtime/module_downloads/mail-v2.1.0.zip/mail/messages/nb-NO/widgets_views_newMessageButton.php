<?php

return [
    'Send message' => 'Send melding',
];
