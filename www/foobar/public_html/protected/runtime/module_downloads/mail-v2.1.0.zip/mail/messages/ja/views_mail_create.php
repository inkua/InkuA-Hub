<?php
return array (
  '<strong>New</strong> message' => '<strong>New</strong> メッセージ',
  'Add recipients' => '宛先を追加',
  'Send' => '送信',
);
