<?php

return [
    'Message' => 'መልዕክት',
    'Subject' => 'ርዕስ',
    'Recipient' => '',
    'Tags' => '',
];
