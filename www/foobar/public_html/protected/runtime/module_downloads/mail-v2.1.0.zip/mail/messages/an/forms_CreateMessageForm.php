<?php
return array (
  'Message' => 'Mensache',
  'Recipient' => 'Destinatario',
  'Subject' => 'Asunto',
  'Tags' => 'Etiquetas',
);
