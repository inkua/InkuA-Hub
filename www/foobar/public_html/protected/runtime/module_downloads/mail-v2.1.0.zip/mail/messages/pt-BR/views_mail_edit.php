<?php

return [
    'Edit message entry' => 'Editar mensagem',
];
