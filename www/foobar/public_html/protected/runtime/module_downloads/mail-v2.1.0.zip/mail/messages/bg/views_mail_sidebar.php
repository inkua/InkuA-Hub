<?php
return array (
  'Groups' => 'Групи',
  'Members' => 'Членове',
  'Spaces' => 'Раздели',
  'User Posts' => 'Потребителски публикации',
);
