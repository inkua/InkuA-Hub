<?php

return [
    'New message from {senderName}' => 'Nová zpráva od uživatele {senderName}',
    'New conversation from {senderName}' => '',
];
