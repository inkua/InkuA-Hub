<?php

return [
    'New message from {senderName}' => 'Nytt meddelande från {senderName}',
    'New conversation from {senderName}' => '',
];
