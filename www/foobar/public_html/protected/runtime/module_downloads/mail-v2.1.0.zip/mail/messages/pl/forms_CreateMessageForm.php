<?php
return array (
  'Message' => 'Wiadomość ',
  'Recipient' => 'Odbiorca ',
  'Subject' => 'Temat ',
  'Tags' => 'Tagi',
);
