<?php
return array (
  'Recipient' => 'ผู้รับ',
  'User {name} is already participating!' => 'ผู้ใช้ {name} เข้าร่วมแล้ว!',
  'You are not allowed to send user {name} is already!' => 'คุณไม่ได้รับอนุญาตให้ส่งผู้ใช้ {name} อยู่แล้ว!',
  'You cannot send a email to yourself!' => 'คุณไม่สามารถส่งอีเมลถึงตัวเองได้!',
);
