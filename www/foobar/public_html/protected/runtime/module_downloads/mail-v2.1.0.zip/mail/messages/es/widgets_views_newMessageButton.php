<?php

return [
    'Send message' => 'Enviar mensaje',
];
