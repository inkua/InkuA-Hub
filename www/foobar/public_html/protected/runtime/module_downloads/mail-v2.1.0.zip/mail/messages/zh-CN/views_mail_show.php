<?php

return [
    '<strong>Confirm</strong> deleting conversation' => '确认<strong>删除讨论</strong>',
    '<strong>Confirm</strong> leaving conversation' => '确认<strong>退出讨论</strong>',
    '<strong>Confirm</strong> message deletion' => '确认<strong>删除消息</strong>',
    'Add user' => '添加用户',
    'Cancel' => '取消',
    'Delete' => '删除',
    'Delete conversation' => '删除讨论',
    'Do you really want to delete this conversation?' => '你真的要删除此讨论？',
    'Do you really want to delete this message?' => '你真的要删除此消息？',
    'Do you really want to leave this conversation?' => '你真的要退出此讨论？',
    'Leave' => '退出',
    'Leave conversation' => '退出讨论',
    'There are no messages yet.' => '还没有消息.',
];
