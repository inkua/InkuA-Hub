<?php
return array (
  '<strong>New</strong> conversation' => '<strong>Nueva</strong> conversación',
  '<strong>New</strong> message' => '<strong>Nuevo</strong> mensaje',
  'Reply now' => 'Responder ahora',
);
