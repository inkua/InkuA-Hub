<?php
return array (
  'Sign up now' => 'Registe-se agora',
);
