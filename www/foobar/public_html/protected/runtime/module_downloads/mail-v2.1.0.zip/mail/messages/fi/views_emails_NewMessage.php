<?php

return [
    '<strong>New</strong> message' => '<strong>Uusi</strong> viesti',
    'Reply now' => 'Vastaa nyt',
    '<strong>New</strong> conversation' => '',
];
