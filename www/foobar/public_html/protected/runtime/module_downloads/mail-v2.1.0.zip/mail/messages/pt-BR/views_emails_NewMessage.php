<?php

return [
    '<strong>New</strong> message' => '<strong>Nova</strong> mensagem',
    'Reply now' => 'Responder agora',
    '<strong>New</strong> conversation' => '',
];
