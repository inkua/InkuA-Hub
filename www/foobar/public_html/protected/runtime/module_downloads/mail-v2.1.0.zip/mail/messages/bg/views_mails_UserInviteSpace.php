<?php
return array (
  'Sign up now' => 'Запиши се сега',
);
