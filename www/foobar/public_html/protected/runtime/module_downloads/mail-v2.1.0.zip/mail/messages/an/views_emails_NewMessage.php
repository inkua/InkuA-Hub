<?php

return [
    '<strong>New</strong> message' => '<strong>Nuevo</strong> mensache',
    '<strong>New</strong> conversation' => '',
    'Reply now' => '',
];
