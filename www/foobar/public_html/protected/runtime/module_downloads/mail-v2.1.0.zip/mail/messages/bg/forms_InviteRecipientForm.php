<?php
return array (
  'Recipient' => 'Получател',
  'User {name} is already participating!' => 'Потребител {name} вече учавства!',
  'You are not allowed to send user {name} is already!' => 'Не ти е позволено да изпратиш потребител {name} вече!',
  'You cannot send a email to yourself!' => 'Не можеш да изпратиш имейл до себе си!',
);
