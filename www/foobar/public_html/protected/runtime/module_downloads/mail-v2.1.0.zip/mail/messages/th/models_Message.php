<?php

return [
    'New message from {senderName}' => 'ข้อความใหม่จาก {senderName}',
    'New conversation from {senderName}' => '',
];
