<?php

return [
    '<strong>New</strong> message' => '<strong>Ново</strong> съобщение',
    'Reply now' => 'Отговори сега',
    '<strong>New</strong> conversation' => '',
];
