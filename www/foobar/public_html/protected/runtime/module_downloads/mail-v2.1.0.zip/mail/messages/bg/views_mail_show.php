<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Потвърди</strong> изтриването на обсъждането',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Потвърди</strong> напускането на обсъждането',
  '<strong>Confirm</strong> message deletion' => '<strong>Потвърди</strong> изтриването на съобщението',
  'Add user' => 'Добави потребител',
  'Cancel' => 'Отказ',
  'Delete' => 'Изтрий',
  'Delete conversation' => 'Изтрий обсъждането',
  'Do you really want to delete this conversation?' => 'Наистина ли искаш да изтриеш обсъждането?',
  'Do you really want to delete this message?' => 'Наистина ли искаш да изтриеш съобщението?',
  'Do you really want to leave this conversation?' => 'Наистина ли искаш да напуснеш обсъждането?',
  'Leave' => 'Напусни',
  'Leave conversation' => 'Напусни обсъждането',
  'There are no messages yet.' => 'Все още нямате съобщения',
);
