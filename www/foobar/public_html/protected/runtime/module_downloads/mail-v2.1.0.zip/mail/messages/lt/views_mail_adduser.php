<?php

return [
    'Add more participants to your conversation...' => 'Pridėti daugiau dalyvių į pokalbį...',
];
