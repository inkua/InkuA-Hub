<?php

return [
    'New message from {senderName}' => '{senderName}さんから新しいメッセージ',
    'New conversation from {senderName}' => '',
];
