# Developer

Since CustomPages version v1.0 external modules can provide own targets through the **CustomPagesService**.

