<?php

namespace humhub\modules\custom_pages\modules\template\models;

/**
 * This is the model class for table "custom_pages_page".
 *
 * The followings are the available columns in table 'custom_pages_page':
 */
interface TemplateContentOwner
{
    public function getTemplateId();
}
