<?php
/* @var $linkColor string */
?>

<style>
    .custom-pages-page a, .panel .panel-body p a {
        color: <?= $linkColor ?>;
    }

    .custom-pages-page a:hover, .panel .panel-body p a:hover {
        color: <?= $linkColor ?>;
        text-decoration: underline;
    }
</style>

