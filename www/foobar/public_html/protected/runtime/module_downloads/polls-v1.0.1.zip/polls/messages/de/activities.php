<?php
return array (
  'Polls' => 'Umfragen',
  'Whenever someone participates in a poll.' => 'Bei jeder Beteiligung an einer Umfrage.',
);
