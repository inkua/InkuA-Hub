<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Non ci sono ancora sondaggi!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Non ci sono ancora sondaggi!</b><br>Creane uno per primo...',
  'Asked by me' => 'Chiesto da me',
  'No answered yet' => 'Ancora nessuna risposta',
  'Only private polls' => 'Solo sondaggi privati',
  'Only public polls' => 'Solo sondaggi pubblici',
);
