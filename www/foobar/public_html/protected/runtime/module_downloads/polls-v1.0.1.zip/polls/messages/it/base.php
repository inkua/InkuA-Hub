<?php

return [
    'Allows to start polls.' => 'Consente di iniziare un sondaggio.',
    'Answers' => 'Risposte',
    'At least one answer is required' => 'E\' necessaria almeno ina risposta.',
    'Cancel' => 'Annulla',
    'Polls' => 'Sondaggi',
    'Save' => 'Salva',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
