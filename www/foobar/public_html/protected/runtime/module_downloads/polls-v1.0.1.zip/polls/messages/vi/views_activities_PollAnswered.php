<?php
return array (
  '{userName} answered the {question}.' => '{userName} đã trả lời {question}.',
);
