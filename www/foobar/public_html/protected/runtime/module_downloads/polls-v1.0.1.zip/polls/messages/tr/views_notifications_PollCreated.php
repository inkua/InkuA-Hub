<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} sizin için bir soru sordu.',
);
