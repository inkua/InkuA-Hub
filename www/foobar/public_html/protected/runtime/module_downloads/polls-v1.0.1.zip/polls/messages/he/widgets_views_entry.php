<?php

return [
    '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '',
    'Anonymous' => '',
    'Closed' => '',
    'Complete Poll' => '',
    'Reopen Poll' => '',
    'Reset my vote' => '',
    'Vote' => '',
    'and {count} more vote for this.' => '',
    'votes' => '',
];
