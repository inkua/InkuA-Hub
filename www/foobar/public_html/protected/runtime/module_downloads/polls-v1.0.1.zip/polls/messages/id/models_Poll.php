<?php
return array (
  'Answers' => 'Jawaban',
  'Description' => 'Deskripsi',
  'Multiple answers per user' => 'Beberapa jawaban per pengguna',
  'Please specify at least {min} answers!' => 'Silahkan tentukan setidaknya {min} jawaban!',
  'Question' => 'Pertanyaan',
);
