<?php
return array (
  'Again? ;Weary;' => 'Atkal? ;Weary;',
  'Club A Steakhouse' => 'Uz steika sviestmaizi',
  'Pisillo Italian Panini' => 'Uz itāļu panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Pašlaik mēs plānojam mūsu nākamo tikšanos un mēs vēlētos uzzināt no tevis, kur tu vēlētos doties?',
  'To Daniel' => 'Pie Daniela',
  'Why don\'t we go to Bemelmans Bar?' => 'Kapēc lai mēs nedotos uz Bemelmana bāru?',
);
