<?php
return array (
  'Answers' => 'پاسخ‌ها',
  'Description' => 'توضیحات',
  'Multiple answers per user' => 'چند پاسخ به ازای هر کاربر',
  'Please specify at least {min} answers!' => 'لطفا حداقل {min} پاسخ مشخص کنید!',
  'Question' => 'سؤال',
);
