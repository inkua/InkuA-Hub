<?php

return [
    '{userName} answered the {question}.' => '',
];
