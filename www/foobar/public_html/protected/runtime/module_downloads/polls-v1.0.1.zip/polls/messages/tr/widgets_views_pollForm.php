<?php
return array (
  'Add answer...' => 'Cevap ekleyin...',
  'Anonymous Votes?' => 'Misafir oy?',
  'Description' => 'Açıklama',
  'Display answers in random order?' => 'Cevapları rastgele sırala?',
  'Edit answer (empty answers will be removed)...' => '',
  'Edit your poll question...' => 'Anket sorusunu düzenle...',
  'Hide results until poll is closed?' => '',
  'Question' => 'Soru',
);
