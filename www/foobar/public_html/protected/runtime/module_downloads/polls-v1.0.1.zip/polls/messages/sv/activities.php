<?php

return [
    'Polls' => '',
    'Whenever someone participates in a poll.' => '',
];
