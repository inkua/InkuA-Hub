<?php

return [
    'Allows to start polls.' => 'Engedélyezi szavazás indítását.',
    'Answers' => 'Válaszok',
    'Cancel' => 'Mégsem',
    'Polls' => 'Szavazás',
    'Save' => 'Mentés',
    'Allows the user to create polls' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
];
