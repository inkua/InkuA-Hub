<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Er zijn nog geen stembussen</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Er zijn nog geen stembussen!</b><br>Wees de eerste en maak er een...',
  'Asked by me' => 'Gevraagd door mij',
  'No answered yet' => 'Nog geen antwoord',
  'Only private polls' => 'Alleen private stembussen',
  'Only public polls' => 'Alleen publieke stembussen',
);
