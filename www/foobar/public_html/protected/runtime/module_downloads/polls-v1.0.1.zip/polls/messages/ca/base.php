<?php

return [
    'Answers' => 'Respostes',
    'Cancel' => 'Cancel·la',
    'Polls' => 'Enquestes',
    'Save' => 'Desa',
    'Allows the user to create polls' => '',
    'Allows to start polls.' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
];
