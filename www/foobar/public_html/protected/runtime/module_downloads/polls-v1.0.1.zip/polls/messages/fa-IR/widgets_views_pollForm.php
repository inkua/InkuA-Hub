<?php
return array (
  'Add answer...' => 'ضافه كردن پاسخ....',
  'Anonymous Votes?' => 'راي دهي ناشناس؟',
  'Description' => 'توضیحات',
  'Display answers in random order?' => 'نشان دادن پاسخ ها بصورت اتفاقي',
  'Edit answer (empty answers will be removed)...' => 'ويرايش پاسخ ها',
  'Edit your poll question...' => 'ويرايش سوال نظرخواهي',
  'Hide results until poll is closed?' => '',
  'Question' => 'سؤال',
);
