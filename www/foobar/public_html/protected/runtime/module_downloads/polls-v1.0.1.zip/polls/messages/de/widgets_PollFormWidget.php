<?php
return array (
  'Ask' => 'Frag',
);
