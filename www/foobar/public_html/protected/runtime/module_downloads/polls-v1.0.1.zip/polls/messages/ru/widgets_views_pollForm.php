<?php
return array (
  'Add answer...' => 'Добавить ответ...',
  'Anonymous Votes?' => 'Опрос анонимный?',
  'Description' => 'Описание',
  'Display answers in random order?' => 'Показывать ответы в случайном порядке?',
  'Edit answer (empty answers will be removed)...' => 'Редактировать ответ (пустые ответы будут удалены)...',
  'Edit your poll question...' => 'Отредактируйте свой вопрос для опроса...',
  'Hide results until poll is closed?' => 'Скрыть результаты, пока опрос не будет завершён?',
  'Question' => 'Опрос',
);
