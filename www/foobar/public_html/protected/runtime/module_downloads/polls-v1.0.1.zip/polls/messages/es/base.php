<?php

return [
    'Allows to start polls.' => 'Permite iniciar encuestas.',
    'Answers' => 'Respuestas',
    'At least one answer is required' => 'Se requiere al menos una respuesta',
    'Cancel' => 'Cancelar',
    'Polls' => 'Votaciones',
    'Save' => 'Guardar',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
