<?php
return array (
  'Answers' => '',
  'Description' => 'Descriere',
  'Multiple answers per user' => '',
  'Please specify at least {min} answers!' => '',
  'Question' => '',
);
