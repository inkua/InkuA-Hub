<?php
return array (
  'Answers' => 'Отговори',
  'Description' => 'Описание',
  'Multiple answers per user' => 'Няколко отговора на потребител',
  'Please specify at least {min} answers!' => 'Моля, посочете поне {min} отговора!',
  'Question' => 'Въпрос',
);
