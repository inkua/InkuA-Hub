<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} یک نظرسنجی جدید ایجاد کرد و به شما اختصاص داد.',
);
