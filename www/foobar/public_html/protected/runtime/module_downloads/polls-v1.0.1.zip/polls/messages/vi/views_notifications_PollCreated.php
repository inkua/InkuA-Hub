<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} đã tạo một biểu quyết mới và gán cho bạn.',
);
