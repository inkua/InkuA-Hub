<?php

return [
    'Allows to start polls.' => 'Ce module permet de créer des sondages.',
    'Answers' => 'Réponses',
    'At least one answer is required' => 'Au moins une réponse est obligatoire',
    'Cancel' => 'Annuler',
    'Polls' => 'Sondages',
    'Save' => 'Enregistrer',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
