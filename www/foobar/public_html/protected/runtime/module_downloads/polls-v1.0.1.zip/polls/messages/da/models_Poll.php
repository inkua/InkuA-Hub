<?php
return array (
  'Answers' => 'Svar',
  'Description' => 'Beskrivelse',
  'Multiple answers per user' => 'Flere svar pr bruger',
  'Please specify at least {min} answers!' => 'Venligst specificer mindst {min} svar!',
  'Question' => 'Spørgsmål',
);
