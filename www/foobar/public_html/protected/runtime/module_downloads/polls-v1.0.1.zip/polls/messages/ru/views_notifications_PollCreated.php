<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} создал(а) новый опрос и назначил его для Вас. ',
);
