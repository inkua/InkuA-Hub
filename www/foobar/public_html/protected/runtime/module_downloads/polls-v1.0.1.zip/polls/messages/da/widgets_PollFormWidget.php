<?php
return array (
  'Ask' => 'Spørg',
);
