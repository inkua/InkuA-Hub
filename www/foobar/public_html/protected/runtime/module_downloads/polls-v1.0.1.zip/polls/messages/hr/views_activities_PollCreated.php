<?php
return array (
  '{userName} created a new {question}.' => '{userName} kreirao je novo {question}.',
);
