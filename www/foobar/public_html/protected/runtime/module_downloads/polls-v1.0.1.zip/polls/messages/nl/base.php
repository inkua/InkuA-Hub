<?php

return [
    'Allows to start polls.' => 'Starten van stembussen toestaan.',
    'Answers' => 'Antwoorden',
    'At least one answer is required' => 'Ten minste één antwoord is vereist',
    'Cancel' => 'Annuleer',
    'Polls' => 'Stembus',
    'Save' => 'Bewaar',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
