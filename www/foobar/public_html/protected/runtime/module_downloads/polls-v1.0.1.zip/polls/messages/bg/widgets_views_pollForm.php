<?php
return array (
  'Add answer...' => 'Добави отговор...',
  'Anonymous Votes?' => 'Анонимни гласове?',
  'Description' => 'Описание',
  'Display answers in random order?' => 'Да се показват ли отговорите в произволен ред?',
  'Edit answer (empty answers will be removed)...' => 'Редактиране на отговора (празните отговори ще бъдат премахнати)...',
  'Edit your poll question...' => 'Редактирайте въпроса си за анкетата...',
  'Hide results until poll is closed?' => 'Да се скрият ли резултатите, докато анкетата не бъде затворена?',
  'Question' => 'Въпрос',
);
