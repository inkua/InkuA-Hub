<?php

return [
    'Allows to start polls.' => 'Cho phép tạo biểu quyết',
    'Answers' => 'Trả lời',
    'At least one answer is required' => 'Yêu cầu ít nhất 1 câu trả lời',
    'Cancel' => 'Hủy',
    'Polls' => 'Biểu quyết',
    'Save' => 'Lưu',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
