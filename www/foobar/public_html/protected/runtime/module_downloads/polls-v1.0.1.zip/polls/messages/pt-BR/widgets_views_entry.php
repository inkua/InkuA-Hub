<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Nota:</ strong> O resultado ficará oculto até que a votação seja fechada por um moderador.',
  'Anonymous' => 'Anônimo',
  'Closed' => 'Fechada',
  'Complete Poll' => 'Completar Enquete',
  'Reopen Poll' => 'Reabrir Enquete',
  'Reset my vote' => 'Redefinir meu voto',
  'Vote' => 'Votar',
  'and {count} more vote for this.' => 'e mais {count} votos para este.',
  'votes' => 'votos',
);
