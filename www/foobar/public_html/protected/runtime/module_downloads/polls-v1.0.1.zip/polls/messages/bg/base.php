<?php

return [
    'Allows to start polls.' => 'Позволява стартиране на анкети.',
    'Answers' => 'Отговори',
    'At least one answer is required' => 'Изисква се поне един отговор',
    'Cancel' => 'Отказ',
    'Polls' => 'Анкети',
    'Save' => 'Запази',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
