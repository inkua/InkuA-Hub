<?php
return array (
  'Allows the user to create polls' => 'Erlaubt es dem Benutzer Umfragen zu erstellen',
  'Allows to start polls.' => 'Ermöglicht Umfragen zu starten.',
  'Answers' => 'Antworten',
  'At least one answer is required' => 'Mindestens eine Antwort erforderlich.',
  'Cancel' => 'Abbrechen',
  'Create poll' => 'Umfrage erstellen',
  'Polls' => 'Umfragen',
  'Save' => 'Speichern',
);
