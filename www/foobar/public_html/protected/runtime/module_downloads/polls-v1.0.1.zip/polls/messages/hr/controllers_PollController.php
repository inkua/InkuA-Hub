<?php
return array (
  'Access denied!' => 'Pristup odbijen!',
  'Anonymous poll!' => 'Anonimna anketa!',
  'Could not load poll!' => 'Nije moguće učitati anketu!',
  'Invalid answer!' => 'Neodgovarajući odgovor!',
  'Users voted for: <strong>{answer}</strong>' => 'Korisnik je glasao za: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Glasanje za višestruke odgovore je onemogućeno!',
  'You have insufficient permissions to perform that operation!' => 'Nemate ovlaštenje za provođenje ove operacije!',
);
