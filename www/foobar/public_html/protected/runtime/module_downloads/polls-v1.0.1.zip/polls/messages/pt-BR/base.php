<?php

return [
    'Allows to start polls.' => 'Permite iniciar enquetes.',
    'Answers' => 'Respostas',
    'At least one answer is required' => 'É necessária pelo menos uma resposta',
    'Cancel' => 'Cancelar',
    'Polls' => 'Enquete',
    'Save' => 'Salvar',
    'Allows the user to create polls' => '',
    'Create poll' => '',
];
