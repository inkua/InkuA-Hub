<?php
return array (
  '{userName} answered the {question}.' => '{userName} hat die {question} beantwortet.',
);
