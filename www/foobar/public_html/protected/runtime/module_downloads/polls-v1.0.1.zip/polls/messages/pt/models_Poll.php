<?php
return array (
  'Answers' => '',
  'Description' => 'Descrição',
  'Multiple answers per user' => '',
  'Please specify at least {min} answers!' => '',
  'Question' => '',
);
