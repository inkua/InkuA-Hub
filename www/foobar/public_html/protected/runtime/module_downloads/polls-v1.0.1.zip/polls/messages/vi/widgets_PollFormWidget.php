<?php
return array (
  'Ask' => 'Hỏi',
);
