<?php

return [
    'Allows to start polls.' => 'Tillåtelse att starta enkäter.',
    'Answers' => 'Svar',
    'Cancel' => 'Avbryt',
    'Polls' => 'Enkät',
    'Save' => 'Spara',
    'Allows the user to create polls' => '',
    'At least one answer is required' => '',
    'Create poll' => '',
];
