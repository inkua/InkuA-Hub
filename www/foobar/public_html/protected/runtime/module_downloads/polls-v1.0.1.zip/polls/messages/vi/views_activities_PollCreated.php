<?php
return array (
  '{userName} created a new {question}.' => '{userName} đã tạo mới {question}.',
);
