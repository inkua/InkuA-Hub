<?php
return array (
  'User who vote this' => 'کاربری که این رای را داده‌است',
);
