<?php
return array (
  'Answers' => '',
  'Description' => 'توضيج',
  'Multiple answers per user' => '',
  'Please specify at least {min} answers!' => '',
  'Question' => '',
);
