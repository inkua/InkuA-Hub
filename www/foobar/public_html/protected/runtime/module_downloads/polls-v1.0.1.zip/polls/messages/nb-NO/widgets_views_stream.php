<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Det er ingen meningsmålinger enda!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Det er ingen meningsmålinger enda!</b><br>Vær førstemann til å lage en...',
  'Asked by me' => 'Spurt av meg',
  'No answered yet' => 'Ikke besvart enda',
  'Only private polls' => 'Bare private meningsmålinger',
  'Only public polls' => 'Bare offentlige meningsmålinger',
);
