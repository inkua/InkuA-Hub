<?php

return [
    'Save' => 'Guardar',
    'Allows the user to create polls' => '',
    'Allows to start polls.' => '',
    'Answers' => '',
    'At least one answer is required' => '',
    'Cancel' => '',
    'Create poll' => '',
    'Polls' => '',
];
