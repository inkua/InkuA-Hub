<?php
return array (
  'Update download failed! (%error%)' => 'Preuzimanje ažuriranja nije uspjelo! (%error%)',
);
