<?php
return array (
  'Update download failed! (%error%)' => 'Päivityksen lataus epäonnistui! (%error%)',
);
