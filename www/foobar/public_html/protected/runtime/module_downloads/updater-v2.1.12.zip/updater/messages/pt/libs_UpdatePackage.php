<?php
return array (
  'Update download failed! (%error%)' => 'Descarregamento da actualização falhou! (%error%)',
);
