<?php
return array (
  'Update download failed! (%error%)' => 'Błąd pobierania aktualizacji! (%error%)',
);
