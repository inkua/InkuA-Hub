<?php
return array (
  'Update download failed! (%error%)' => 'Ha fallado la descarga de la actualización (%error%)',
);
