<?php
return array (
  'Update download failed! (%error%)' => 'Herunterladen des Updates fehlgeschlagen! (%error%)',
);
