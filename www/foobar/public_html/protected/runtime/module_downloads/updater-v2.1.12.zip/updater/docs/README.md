# HumHub Updater

This module allows you to update the software via a web interface, making the updating process fast and easy, especially for smaller updates. Please keep in mind, that, for major updates and bigger communities, the documentation should be consulted in any case. Especially when custom Modules and Themes are being used. 

For detailed information and a step-by-step instructions on how to manually update your HumHub installation, please refer to our documentation: [Updating HumHub](https://docs.humhub.org/docs/admin/updating)
