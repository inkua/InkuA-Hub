<?php
return array (
  'Update download failed! (%error%)' => 'อัปเดตการดาวน์โหลดล้มเหลว! (%ผิดพลาด%)',
);
